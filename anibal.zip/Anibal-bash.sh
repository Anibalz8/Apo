#!/bin/bash
echo Enter your name
read name
echo Hi $name !
echo Hello World
